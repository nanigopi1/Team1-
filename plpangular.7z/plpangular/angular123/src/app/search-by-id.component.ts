import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';
import { Product } from './search/Interface';
import { Router } from '../../node_modules/@angular/router';

@Component({
  selector: 'app-search-by-id',
  templateUrl: './search-by-id.component.html',
  styleUrls: ['./search-by-id.component.css']
})
export class SearchByIdComponent implements OnInit {
  products:Product[];
  private list:any[];
  deliveryStatus:String;
  initial:boolean=true;
  private result:any[]=[];
  a=false;
  s=false;
  saved:boolean;
  message:any;
  m=false;
  buttonDisplay=false;

  constructor(private service:ProductService,private router:Router) { }

  ngOnInit() {
  }
  getDetails(storeid,orderid){
    this.a=true;
    this.initial=false;
    this.s=true;

    this.service.getDetails(storeid,orderid).subscribe((data:any)=>{this.result=data;
    });
  }
  goToHome(){
    this.router.navigate(['/home']);
  }
  onUpdate(){
    this.a=false;
  this.buttonDisplay=true;
    }
  save(storeid,orderid,status){
    this.m=true;
    this.s=false;
    this.buttonDisplay=false;
    if(status=="completed" || status=="initiated" || status=="not completed" || status=="not initiated"){
    this.service.update(storeid,orderid,status).subscribe((data:any)=>{
      this.saved=data;
    if(this.saved){
      alert("saved successfully!!");
      this.message="saved successfully!!";
    }
    else{
      alert("Not saved successfully!!");

    }
  });
}
else
alert("This is the default alert!");
  }

}
