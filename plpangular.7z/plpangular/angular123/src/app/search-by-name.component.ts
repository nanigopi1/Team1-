import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';
import { Product } from './search/Interface';
import { Router } from '../../node_modules/@angular/router';

@Component({
  selector: 'app-search-by-name',
  templateUrl: './search-by-name.component.html',
  styleUrls: ['./search-by-name.component.css']
})
export class SearchByNameComponent implements OnInit {

  products:Product[];
  private list:any[];
  deliveryStatus:String;
  private result:any[]=[];
  a=false;
  s=false;
  initial:boolean=true;
  saved:boolean;
  message:any;
  m=false;
  buttonDisplay=false;
  constructor(private service:ProductService,private router:Router) { }

  ngOnInit() {
  }
  goToHome(){
    this.router.navigate(['/home']);
  }
  order(ordername){
   
    this.service.searchbyitemname(ordername).subscribe((data:any)=>{
      this.initial=false;
      this.list=data;
      this.s=true;
 
      });
    }

}
