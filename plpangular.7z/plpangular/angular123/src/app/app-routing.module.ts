import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchByIdComponent } from './search-by-id.component';
import { SearchByNameComponent } from './search-by-name.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {path:'searchbyid',component:SearchByIdComponent},
  {path:'searchbyname',component:SearchByNameComponent},
  {path:'home',component:HomeComponent},
  {path:'',redirectTo:'/home',pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
