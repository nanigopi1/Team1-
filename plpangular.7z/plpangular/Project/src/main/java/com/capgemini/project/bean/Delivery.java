package com.capgemini.project.bean;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Delivery {
	
	
	@XmlAttribute
	private String value;
	private String deliveryStatus;
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	
	public Delivery() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Delivery(String value, String deliveryStatus) {
		super();
		this.value = value;
		this.deliveryStatus = deliveryStatus;
	}
	
	
	
	
	
	
	
	

}
