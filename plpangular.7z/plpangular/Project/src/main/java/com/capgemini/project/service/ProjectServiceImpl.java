package com.capgemini.project.service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.project.Dao.ProjectDao;
import com.capgemini.project.bean.PurchseDetails;
import com.capgemini.project.bean.Transaction;
import com.capgemini.project.bean.TransactionDetails;
import com.capgemini.project.bean.Transactions;

@Service
public class ProjectServiceImpl implements ProjectService {

	
	@Autowired
	ProjectDao ProjectRepo;
	
	@Override
	public void paymentMode() {
		String path="C:\\Users\\madamadh\\Desktop\\cash.xml";
		String path1="C:\\Users\\madamadh\\Desktop\\credit.xml";
		String path2="C:\\Users\\madamadh\\Desktop\\debit.xml";
		File file=new File(path);
		File file1=new File(path1);
		File file2=new File(path2);
		List<Transaction> transcations=ProjectRepo.get();
		List<Transaction> transcationCash=new ArrayList<Transaction>();
		List<Transaction> transcationdebitcard=new ArrayList<Transaction>();
		List<Transaction> transcationcreditcard=new ArrayList<Transaction>();
		
		
		for (int i = 0; i < transcations.size(); i++) {
			
			Transaction transaction1=transcations.get(i);
			List<TransactionDetails> td=transaction1.getTranscationdetails();
			
			
			List<TransactionDetails> tdCash=new ArrayList<TransactionDetails>();
			List<TransactionDetails> tddebitcard=new ArrayList<TransactionDetails>();
			List<TransactionDetails> tdcreditcard=new ArrayList<TransactionDetails>();
			
			
			for (int j = 0; j < td.size(); j++) {
				TransactionDetails td1=td.get(j);
				if (td1.getPaymentMode().equalsIgnoreCase("cash")) {
					tdCash.add(td1);
					
				}
				
				if (td1.getPaymentMode().equalsIgnoreCase("debit")) {
					tddebitcard.add(td1);
					
				}
				
				if (td1.getPaymentMode().equalsIgnoreCase("credit")) {
					tdcreditcard.add(td1);
					
				}
				
			}
			
			if (tdCash.size()!=0) {
				
				Transaction t1=new Transaction();
				t1.setRetailStoreID(transaction1.getRetailStoreID());
				t1.setTranscationdetails(tdCash);
				transcationCash.add(t1);
				
			}
			
			if (tddebitcard.size()!=0) {
				
				Transaction t2=new Transaction();
				t2.setRetailStoreID(transaction1.getRetailStoreID());
				t2.setTranscationdetails(tddebitcard);
				transcationdebitcard.add(t2);
			}

			if (tdcreditcard.size()!=0) {
	
				Transaction t3=new Transaction();
				t3.setRetailStoreID(transaction1.getRetailStoreID());
				t3.setTranscationdetails(tdcreditcard);
				transcationcreditcard.add(t3);
			}
			
		}
		
		
		Transactions tr1=new Transactions();
		tr1.setTranscations(transcationCash);
		
		try {
			JAXBContext context=JAXBContext.newInstance(Transactions.class);
			Marshaller marshler=context.createMarshaller();
			marshler.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			marshler.marshal(tr1,file);
			
		} catch (JAXBException e) {
			
			System.out.println("Unable to covert into cash.xml file");
		}
		
		
		Transactions tr2=new Transactions();
		tr2.setTranscations(transcationdebitcard);
		
		try {
			JAXBContext context=JAXBContext.newInstance(Transactions.class);
			Marshaller marshler=context.createMarshaller();
			marshler.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			marshler.marshal(tr2,file2);
			
		} catch (JAXBException e) {
			
			System.out.println("Unable to covert into debit.xml file");
		}
		
		
		Transactions tr3=new Transactions();
		tr3.setTranscations(transcationcreditcard);
		
		try {
			JAXBContext context=JAXBContext.newInstance(Transactions.class);
			Marshaller marshler=context.createMarshaller();
			marshler.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			marshler.marshal(tr3,file1);
			
		} catch (JAXBException e) {
			
			System.out.println("Unable to covert into credit.xml file");
		}
		
		
	
		
	}

	@Override
	public String update(Integer sid, Integer oid, String deliverystatus) {
		
		return ProjectRepo.update(sid, oid, deliverystatus);
	}

	@Override
	public TransactionDetails GetOderDetails(Integer sid, Integer oid) {
		
		return ProjectRepo.getOrderDetails(sid, oid);
	}

	@Override
	public List<PurchseDetails> getByName(String item) {
		
		return ProjectRepo.getByName(item);
	}
	
	

}
