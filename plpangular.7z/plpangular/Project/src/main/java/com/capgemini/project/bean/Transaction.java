package com.capgemini.project.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@XmlRootElement
@Document(collection = "Transcation1")
public class Transaction {
	
	
	@Id
	private Integer retailStoreID;
	private List<TransactionDetails> transcationdetails;
	public Integer getRetailStoreID() {
		return retailStoreID;
	}
	public void setRetailStoreID(Integer retailStoreID) {
		this.retailStoreID = retailStoreID;
	}
	public List<TransactionDetails> getTranscationdetails() {
		return transcationdetails;
	}
	public void setTranscationdetails(List<TransactionDetails> transcationdetails) {
		this.transcationdetails = transcationdetails;
	}
	public Transaction(Integer retailStoreID, List<TransactionDetails> transcationdetails) {
		super();
		this.retailStoreID = retailStoreID;
		this.transcationdetails = transcationdetails;
	}
	public Transaction() {
		super();
		
	}


	
	
	
	
	
	

}
