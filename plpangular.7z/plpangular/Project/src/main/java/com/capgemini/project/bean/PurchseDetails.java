package com.capgemini.project.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class PurchseDetails {
	
	@XmlAttribute
	private Integer orderId;
	private List<Item> items;
	private Double totalAmount;
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public List<Item> getItems() {
		return items;
	}
	public void setItems(List<Item> items) {
		this.items = items;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public PurchseDetails(Integer orderId, List<Item> items, Double totalAmount) {
		super();
		this.orderId = orderId;
		this.items = items;
		this.totalAmount = totalAmount;
	}
	public PurchseDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	

}
