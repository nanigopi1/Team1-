package com.capgemini.project.Dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.capgemini.project.bean.Delivery;
import com.capgemini.project.bean.Item;
import com.capgemini.project.bean.PurchseDetails;
import com.capgemini.project.bean.Transaction;
import com.capgemini.project.bean.TransactionDetails;

@Repository
public class ProjectDaoImpl implements ProjectDao{

	
	@Autowired
	MongoTemplate mongo1;
	
	@Override
	public void add(Transaction details) {		
	     mongo1.insert(details);
	}

	@Override
	public List<Transaction> get() {
		
		List<Transaction> tr=mongo1.findAll(Transaction.class);
		
		return tr;
	}

	@Override
	public void Delete() {
		
		
	}

	@Override
	public String update(Integer sid, Integer oid, String deliverystatus) {
	       List<Transaction> transaction=mongo1.findAll(Transaction.class);
	       for (int i = 0; i < transaction.size(); i++) {
	    	   Transaction tr=transaction.get(i);
	    	   Integer storeid= tr.getRetailStoreID();
	    	   
	    	   if(storeid.equals(sid)) {
	    		   List<TransactionDetails> td=tr.getTranscationdetails();
	    		   for (int j = 0; j < td.size(); j++) {
					TransactionDetails tdetail=td.get(j);
					PurchseDetails pd=tdetail.getPurchseDetails();
					Integer orderid=pd.getOrderId();
					if (orderid.equals(oid)) {
						Delivery deliverydetails=tdetail.getDelivery();
						if (deliverystatus.equalsIgnoreCase("Completed")) {
							deliverydetails.setDeliveryStatus(deliverystatus);
							deliverydetails.setValue("yes");
							mongo1.save(tr);
						}
						else {
						deliverydetails.setDeliveryStatus(deliverystatus);
						deliverydetails.setValue("No");
						mongo1.save(tr);
						}
						return "sucessfullyupdated";
						
					}
				}
	    		   
	    	   }
			
		}
		return "please enter a valid details";
	}

	@Override
	public TransactionDetails getOrderDetails(Integer sid, Integer oid) {
		TransactionDetails tdetail1=new TransactionDetails();
		  List<Transaction> transaction=mongo1.findAll(Transaction.class);
	       for (int i = 0; i < transaction.size(); i++) {
	    	   Transaction tr=transaction.get(i);
	    	   Integer storeid= tr.getRetailStoreID();
	    	   
	    	   if(storeid.equals(sid)) {
	    		   List<TransactionDetails> td=tr.getTranscationdetails();
	    		   for (int j = 0; j < td.size(); j++) {
					TransactionDetails tdetail=td.get(j);
					PurchseDetails pd=tdetail.getPurchseDetails();
					Integer orderid=pd.getOrderId();
					if (orderid.equals(oid)) {
						Delivery deliverydetails=tdetail.getDelivery();
						tdetail1=tdetail;	
					}
				}
	    		   
	    	   }
			
		}
		
		
		return tdetail1;
	}

	@Override
	public List<PurchseDetails> getByName(String item) {
		List<Transaction> transactionlist= mongo1.findAll(Transaction.class);
		List<PurchseDetails> updatedpdlist=new ArrayList<PurchseDetails>();
		for (int i = 0; i < transactionlist.size(); i++) {
			Transaction trnsaction= transactionlist.get(i);
			List<TransactionDetails> tdlist=trnsaction.getTranscationdetails();
			for (int j = 0; j < tdlist.size(); j++) {
				TransactionDetails tdetails=tdlist.get(j);
				PurchseDetails purchasedetails=tdetails.getPurchseDetails();
				List<Item> itemlist= purchasedetails.getItems();
				List<Item> updatedil=new ArrayList<Item>();
				for (int k = 0; k < itemlist.size(); k++) {
					Item item1= itemlist.get(k);
					if (item1.getItemName().equalsIgnoreCase(item)) {	
						updatedil.add(item1);	
					}	
				}
				
				if (updatedil.size()!=0) {
					PurchseDetails updatedpd=new PurchseDetails();
					updatedpd.setOrderId(purchasedetails.getOrderId());
					updatedpd.setTotalAmount(purchasedetails.getTotalAmount());
					updatedpd.setItems(updatedil);
					updatedpdlist.add(updatedpd);
				}
				
			}
		}
		return updatedpdlist;
	}

}
