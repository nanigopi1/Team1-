package com.capgemini.project.service;

import java.util.List;

import com.capgemini.project.bean.PurchseDetails;
import com.capgemini.project.bean.TransactionDetails;

public interface ProjectService {
	
	public void paymentMode();
	
	public String update(Integer sid,Integer oid,String deliverystatus) ;
	
	public TransactionDetails GetOderDetails(Integer sid,Integer oid);
	
	public List<PurchseDetails> getByName(String item);

}
