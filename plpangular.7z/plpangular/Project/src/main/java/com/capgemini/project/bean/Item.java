package com.capgemini.project.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Item {
	
	private Integer itemID;
	private String itemName;
	private Double amount;
	private Integer quantity;
	public Integer getItemID() {
		return itemID;
	}
	public void setItemID(Integer itemID) {
		this.itemID = itemID;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Item(Integer itemID, String itemName, Double amount, Integer quantity) {
		super();
		this.itemID = itemID;
		this.itemName = itemName;
		this.amount = amount;
		this.quantity = quantity;
	}
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
