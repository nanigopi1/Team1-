package com.capgemini.project.Controller;

import java.io.File;

import java.util.List;


import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.capgemini.project.Dao.ProjectDao;

import com.capgemini.project.bean.PurchseDetails;
import com.capgemini.project.bean.Transaction;
import com.capgemini.project.bean.TransactionDetails;
import com.capgemini.project.bean.Transactions;
import com.capgemini.project.service.ProjectService;


import java.io.File;
import java.io.IOException;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.xml.sax.SAXException;

@RestController
@RequestMapping("/PProject")
@CrossOrigin(origins="http://localhost:4200") 
public class ProjectController {
	
	@Autowired
	ProjectDao rep;
	
	@Autowired
	ProjectService service;
	
	@PutMapping("/add")
	public void unMarshall() {
		String path="C:\\Users\\madamadh\\Desktop\\Schemas\\store5.xml";
		File file=new File(path);
		try {
			JAXBContext jc=JAXBContext.newInstance(Transaction.class);
			Unmarshaller ums=jc.createUnmarshaller();
			Transaction trans=(Transaction) ums.unmarshal(file);
			rep.add(trans);
			marshall();
			card();
			
		} 
		catch (JAXBException e) {
			System.out.println("File not getting stored in the database");
		}	
	}
	
	
	@GetMapping("/get")
	public void marshall() {
		
		List<Transaction> tr=rep.get();
		Transactions tr1=new Transactions();
		tr1.setTranscations(tr);
		
		try {
			JAXBContext context=JAXBContext.newInstance(Transactions.class);
			Marshaller marshler=context.createMarshaller();
			marshler.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			System.out.println(tr);
			marshler.marshal(tr1,new File("Transcations.xml"));
			
		} catch (JAXBException e) {
			
			System.out.println("File not updated successfully");
		}
				
		
		
	}
	
	@GetMapping("/card")
    public void card() {
    	service.paymentMode();
    }
	
	
	@PutMapping("/update")
	public boolean update(@RequestParam("sid") Integer sid,@RequestParam("oid") Integer oid,@RequestParam("deliverystatus") String deliverystatus ) {
		 
		if(service.update(sid, oid, deliverystatus).equalsIgnoreCase("sucessfullyupdated")){
			
			
		
		 return true;
		}
		else {
			return false;
			
		}
	
	}
	
	
	@GetMapping("/GetOrderDetails")
	public TransactionDetails getOrderDetails(@RequestParam("sid") Integer sid,@RequestParam("oid") Integer oid) {
		 
		return service.GetOderDetails(sid, oid);
	
	}
	
	
	@GetMapping("/GetItems")
	public List<PurchseDetails> getOderDetails(@RequestParam("Item") String Item) {
		 
		return service.getByName(Item);
	
	}
	
	public static boolean validateXMLSchema(String xsdPath, File xmlPath){
	      try {
	         SchemaFactory factory =
	            SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
	            Schema schema = factory.newSchema(new File(xsdPath));
	            Validator validator = schema.newValidator();
	            validator.validate(new StreamSource(xmlPath));
	      } catch (IOException e){
	         System.out.println("Exception: "+e.getMessage());
	         return false;
	      }catch(SAXException e1){
	         System.out.println("SAX Exception: "+e1.getMessage());
	         return false;
	      }
	  
	      return true;
	 
	   }

	
	
	
	
}
