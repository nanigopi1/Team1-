package com.capgemini.project.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.data.mongodb.core.mapping.Document;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Document
public class TransactionDetails {
	
	@XmlElement
	private String businessDayDate;
	
	@XmlElement
	private PurchseDetails purchseDetails;
	
	@XmlElement
	private Delivery delivery;
	
	@XmlElement
	private String paymentMode;

	public String getBusinessDayDate() {
		return businessDayDate;
	}

	public void setBusinessDayDate(String businessDayDate) {
		this.businessDayDate = businessDayDate;
	}

	public PurchseDetails getPurchseDetails() {
		return purchseDetails;
	}

	public void setPurchseDetails(PurchseDetails purchseDetails) {
		this.purchseDetails = purchseDetails;
	}

	public Delivery getDelivery() {
		return delivery;
	}

	public void setDelivery(Delivery delivery) {
		this.delivery = delivery;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public TransactionDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TransactionDetails(String businessDayDate, PurchseDetails purchseDetails, Delivery delivery,
			String paymentMode) {
		super();
		this.businessDayDate = businessDayDate;
		this.purchseDetails = purchseDetails;
		this.delivery = delivery;
		this.paymentMode = paymentMode;
	}
	
	
	
}
