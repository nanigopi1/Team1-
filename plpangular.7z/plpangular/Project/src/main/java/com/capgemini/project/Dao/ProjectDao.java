package com.capgemini.project.Dao;

import java.util.List;

import com.capgemini.project.bean.PurchseDetails;
import com.capgemini.project.bean.Transaction;
import com.capgemini.project.bean.TransactionDetails;

public interface ProjectDao {
	
	public void add(Transaction details);
	
	public List<Transaction> get();

	public void Delete();
	
	public String update(Integer sid,Integer oid,String deliverystatus) ;
	
	public TransactionDetails getOrderDetails(Integer sid,Integer oid);
	
	public List<PurchseDetails> getByName(String item);

	
}
