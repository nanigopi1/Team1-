package com.capgemini.project;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Repository;

import com.capgemini.project.Dao.ProjectDao;
import com.capgemini.project.Dao.ProjectDaoImpl;
import com.capgemini.project.bean.Delivery;
import com.capgemini.project.bean.Item;
import com.capgemini.project.bean.PurchseDetails;
import com.capgemini.project.bean.Transaction;
import com.capgemini.project.bean.TransactionDetails;

@SpringBootApplication
@ComponentScan("com.capgemini.project")
public class ProjectApplication {
	
	

	public static void main(String[] args) {
		SpringApplication.run(ProjectApplication.class, args);	
	}

}
